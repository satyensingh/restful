package com.restfully.shop.services;

public class CustomerNotFoundException extends RuntimeException {
	public CustomerNotFoundException(String s) {
		super(s);
	}
}
